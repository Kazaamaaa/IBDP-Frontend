
const FooterAdmin = () => {
    return(
        <>
        
        </>
    );
}

export default FooterAdmin